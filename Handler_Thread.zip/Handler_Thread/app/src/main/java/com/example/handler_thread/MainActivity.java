package com.example.handler_thread;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.Random;

public class MainActivity extends Activity {

    ProgressBar bar1, bar2;
    TextView msgWorking, msgReturned;
    Button btnStart;
    boolean isRunning = false;
    final int MAX_SEC = 60;
    String strTest = "global value seen by all threads ";
    int intTest = 0;

    // ✅ Handler آمن من تسرب الذاكرة
    static class MyHandler extends Handler {
        WeakReference<MainActivity> activityRef;

        MyHandler(MainActivity activity) {
            super(Looper.getMainLooper());
            activityRef = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            MainActivity activity = activityRef.get();
            if (activity != null) {
                String returnedValue = (String) msg.obj;
                activity.msgReturned.setText("📤 Returned from thread:\n\n" + returnedValue);
                activity.bar1.incrementProgressBy(1);

                if (activity.bar1.getProgress() >= activity.MAX_SEC) {
                    activity.msgReturned.setText("✅ Done - Thread finished.");
                    activity.isRunning = false;
                }

                if (activity.bar1.getProgress() == activity.bar1.getMax()) {
                    activity.msgWorking.setText("🎉 All done!");
                    activity.bar1.setVisibility(View.INVISIBLE);
                    activity.bar2.setVisibility(View.INVISIBLE);
                    activity.btnStart.setEnabled(true);
                } else {
                    activity.msgWorking.setText("⏳ Working... " + activity.bar1.getProgress() + "s");
                }
            }
        }
    }

    MyHandler handler = new MyHandler(this);

    @Override
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_main);

        bar1 = findViewById(R.id.progress);
        bar2 = findViewById(R.id.progress2);
        msgWorking = findViewById(R.id.TextView01);
        msgReturned = findViewById(R.id.TextView02);
        btnStart = findViewById(R.id.btnStart);

        bar1.setMax(MAX_SEC);
        bar1.setProgress(0);

        btnStart.setOnClickListener(v -> {
            btnStart.setEnabled(false);
            bar1.setProgress(0);
            bar1.setVisibility(View.VISIBLE);
            bar2.setVisibility(View.VISIBLE);
            msgReturned.setText("");
            msgWorking.setText("Starting...");
            isRunning = true;
            startThread();
        });

        strTest += "-01";
        intTest = 1;
    }

    private void startThread() {
        Thread backgroundThread = new Thread(() -> {
            try {
                for (int i = 0; i < MAX_SEC && isRunning; i++) {
                    Thread.sleep(1000);
                    Random rnd = new Random();
                    String data = "Thread Value: " + rnd.nextInt(101);
                    data += "\n" + strTest + " " + intTest;
                    intTest++;

                    Message msg = handler.obtainMessage(1, data);
                    if (isRunning) {
                        handler.sendMessage(msg);
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        backgroundThread.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        isRunning = false;
    }
}