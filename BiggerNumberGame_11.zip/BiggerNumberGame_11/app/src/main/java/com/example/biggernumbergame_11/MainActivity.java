package com.example.biggernumbergame_11;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button buttonLeft;
    private Button buttonRight;
    private TextView scoreText;
    private int score = 0;
    private Random random = new Random();

     @Override
     protected void onCreate(Bundle savedInstanceState) {
     super.onCreate(savedInstanceState);
     EdgeToEdge.enable(this);
     setContentView(R.layout.activity_main);

     ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
     Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
     v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
     return insets;
     });

     buttonLeft = findViewById(R.id.buttonLeft);
     buttonRight = findViewById(R.id.buttonRight);
     scoreText = findViewById(R.id.scoreText);

    generateNewNumbers();

     buttonLeft.setOnClickListener(view -> checkAnswer(true));
     buttonRight.setOnClickListener(view -> checkAnswer(false));
     }

     private void generateNewNumbers() {
    int num1 = random.nextInt(100);
     int num2 = random.nextInt(100);

     // إعادة التوليد لو تساويا
     while (num1 == num2) {
     num2 = random.nextInt(100);
     }

     buttonLeft.setText(String.valueOf(num1));
     buttonRight.setText(String.valueOf(num2));
     }

     private void checkAnswer(boolean isLeftButton) {
     int leftNum = Integer.parseInt(buttonLeft.getText().toString());
    int rightNum = Integer.parseInt(buttonRight.getText().toString());

     boolean isCorrect = (isLeftButton && leftNum > rightNum) || (!isLeftButton && rightNum > leftNum);

     if (isCorrect) {
     score++;
     Toast.makeText(this, "correct\uD83D\uDE0E", Toast.LENGTH_SHORT).show();
     } else {
     score--;
     Toast.makeText(this, "wrong\uD83D\uDE05", Toast.LENGTH_SHORT).show();
     }

    scoreText.setText("points: " + score);
     generateNewNumbers();
     }
}