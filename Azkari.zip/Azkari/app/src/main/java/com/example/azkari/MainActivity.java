package com.example.azkari;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;
// اسم pakage:android.speech.tts
//اعداد الطالبة: ملاك محمود شكشك....ابرار فتحي احمد...اسراء مشكان
public class MainActivity extends AppCompatActivity {
    private TextView dhikrText;
    private ImageButton settingsButton;
    private TextToSpeech tts;
    private TextView morningDhikr1;
    private TextView morningDhikr2;
    private TextView eveningDhikr1;
    private TextView eveningDhikr2;
    private TextView welcomeText;
    private SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        dhikrText = findViewById(R.id.dhikrText);
        settingsButton = findViewById(R.id.settingsButton);
        preferences = getSharedPreferences("TalkifyPrefs", MODE_PRIVATE);
        morningDhikr1 = findViewById(R.id.morningDhikr1);
        morningDhikr2 = findViewById(R.id.morningDhikr2);
        eveningDhikr1 = findViewById(R.id.eveningDhikr1);
        eveningDhikr2 = findViewById(R.id.eveningDhikr2);
        welcomeText=findViewById(R.id.welcomeText);
//         استعادة الإعدادات المحفوظة
        float rate = preferences.getFloat("rate", 1.0f);
        float pitch = preferences.getFloat("pitch", 1.0f);
        String lang = preferences.getString("lang", "ar");

        Locale locale = new Locale(lang);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(locale);
                tts.setSpeechRate(rate);
                tts.setPitch(pitch); }
        });

        morningDhikr1.setOnLongClickListener(v -> {
            String text = morningDhikr1.getText().toString();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            return true;
        });
        morningDhikr2.setOnLongClickListener(v -> {
            String text = morningDhikr2.getText().toString();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            return true;
        });

        eveningDhikr1.setOnLongClickListener(v -> {
            String text = eveningDhikr1.getText().toString();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            return true;
        });

        eveningDhikr2.setOnLongClickListener(v -> {
            String text = eveningDhikr2.getText().toString();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            return true;
        });
        welcomeText.setOnLongClickListener(v -> {
            String text = welcomeText.getText().toString();
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
            return true;
        });
//         فتح صفحة الإعدادات
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent); });
//          نطق الذكر عند الضغط المطول
//    dhikrText.setOnLongClickListener(v -> {
//        String text = dhikrText.getText().toString();
//        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
//        return true; }
//    );
    }
    @Override
    protected void onResume() {
        super.onResume();

        if (tts != null) {
            tts.shutdown(); // اغلق القديم لتجنب التعارض
        }


        // أعد تحميل الإعدادات من SharedPreferences
        SharedPreferences preferences = getSharedPreferences("TalkifyPrefs", MODE_PRIVATE);
        float rate = preferences.getFloat("rate", 1.0f);
        float pitch = preferences.getFloat("pitch", 1.0f);
        String lang = preferences.getString("lang", "ar");
        Locale locale = new Locale(lang);
        TextView morningDhikr1 = findViewById(R.id.morningDhikr1);
        TextView morningDhikr2 = findViewById(R.id.morningDhikr2);
        TextView eveningDhikr1 = findViewById(R.id.eveningDhikr1);
        TextView eveningDhikr2 = findViewById(R.id.eveningDhikr2);
//        TextView dhikrText = findViewById(R.id.dhikrText);

        switch (lang) {
            case "ar":
//                dhikrText.setText("اللهم اجعل هذا التطبيق نورًا في دربي");
                morningDhikr1.setText(" أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ.\n" +
                        "رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هٰذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هٰذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.");
                morningDhikr2.setText("اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.");
                eveningDhikr1.setText(" أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ.\n" +
                        "رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هٰذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هٰذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.");
                eveningDhikr2.setText(" رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا.");
                welcomeText.setText("مرحباً بك في تطبيق Azkari، هذا تطبيق تجريبي لتحويل الأذكار إلى صوت بلغات متعددة");

                break;
            case "en":
//                dhikrText.setText("O Allah, make this app a light in my path.");
                morningDhikr1.setText( "We have entered the morning, and the dominion belongs to Allah. All praise is due to Allah. There is no god but Allah, alone without partner. To Him belongs the dominion and all praise, and He is over all things competent.\nO Lord, I ask You for the good of this day and the good of what comes after it, and I seek refuge in You from the evil of this day and the evil of what comes after it.\nO Lord, I seek refuge in You from laziness and the evil of old age.\nO Lord, I seek refuge in You from punishment in the Fire and punishment in the grave.");
                morningDhikr2.setText("O Allah, by You we enter the morning, and by You we enter the evening. By You we live, and by You we die, and to You is the resurrection.");
                eveningDhikr1.setText( "We have entered the morning, and the dominion belongs to Allah. All praise is for Allah. There is no deity but Allah, alone without partner. To Him belongs the dominion and all praise, and He is over all things competent.\nO my Lord, I ask You for the good of this day and what comes after it, and I seek refuge in You from the evil of this day and what comes after it.\nO my Lord, I seek refuge in You from laziness and the trials of old age.\nO my Lord, I seek refuge in You from the punishment of Hellfire and the punishment of the grave.");
                eveningDhikr2.setText( "I am pleased with Allah as my Lord, with Islam as my religion, and with Muhammad ﷺ as my Prophet.");
                welcomeText.setText( "Welcome to the Azkari app. This is a trial application that converts supplications (adhkar) into voice in multiple languages.");
                break;
            case "fr":
//                dhikrText.setText("Ô Allah, fais de cette application une lumière sur mon chemin.");
                morningDhikr1.setText( "Nous sommes entrés dans le matin et la royauté appartient à Allah. Louange à Allah. Il n'y a de divinité qu'Allah, seul, sans associé. À Lui la royauté et à Lui la louange, et Il est capable de toute chose.\nSeigneur, je Te demande le bien de ce jour et le bien de ce qui suit, et je cherche refuge auprès de Toi contre le mal de ce jour et le mal de ce qui suit.\nSeigneur, je cherche refuge auprès de Toi contre la paresse et les affres de la vieillesse.\nSeigneur, je cherche refuge auprès de Toi contre le châtiment du Feu et celui de la tombe.");
                morningDhikr2.setText("Ô Allah, par Toi nous commençons le matin, et par Toi nous terminons le soir. Par Toi nous vivons, par Toi nous mourons, et vers Toi est la résurrection.");
                eveningDhikr1.setText( "Nous sommes entrés dans le matin et le royaume appartient à Allah. Louange à Allah. Il n’y a de divinité qu’Allah, seul, sans associé. À Lui la royauté et à Lui la louange, et Il est capable de toute chose.\nSeigneur, je Te demande le bien de ce jour et de ce qui vient après, et je cherche refuge auprès de Toi contre le mal de ce jour et de ce qui vient après.\nSeigneur, je cherche refuge auprès de Toi contre la paresse et les difficultés de la vieillesse.\nSeigneur, je cherche refuge auprès de Toi contre le châtiment du Feu et celui de la tombe.");
                eveningDhikr2.setText("Je suis satisfait d’Allah comme Seigneur, de l’Islam comme religion, et de Muhammad ﷺ comme Prophète.");
                welcomeText.setText("Bienvenue dans l'application Azkari. Ceci est une application expérimentale pour convertir les invocations (adhkar) en voix dans plusieurs langues.");
                break;
            case "it":
//                dhikrText.setText("O Allah, rendi questa app una luce sul mio cammino.");
                morningDhikr1.setText("Siamo entrati nel mattino e il regno appartiene ad Allah. Lode ad Allah. Non c'è divinità all'infuori di Allah, l'Unico, senza socio. A Lui appartiene il regno e a Lui la lode, ed Egli è onnipotente.\nO Signore, Ti chiedo il bene di questo giorno e il bene di ciò che verrà dopo, e Ti chiedo protezione contro il male di questo giorno e il male di ciò che verrà dopo.\nO Signore, Ti chiedo protezione dalla pigrizia e dalla cattiva vecchiaia.\nO Signore, Ti chiedo protezione dal castigo del Fuoco e dal castigo della tomba.");
                morningDhikr2.setText( "O Allah, con Te iniziamo il mattino, con Te entriamo nella sera. Con Te viviamo, con Te moriamo, e a Te è la resurrezione.");
                eveningDhikr1.setText( "Siamo entrati nel mattino e il regno appartiene ad Allah. La lode appartiene ad Allah. Non c’è altro dio che Allah, l’Unico, senza associati. A Lui appartiene il regno e la lode, ed Egli è onnipotente.\nO mio Signore, Ti chiedo il bene di questo giorno e di ciò che viene dopo, e cerco rifugio in Te dal male di questo giorno e di ciò che viene dopo.\nO mio Signore, cerco rifugio in Te dalla pigrizia e dalla cattiva vecchiaia.\nO mio Signore, cerco rifugio in Te dal castigo del Fuoco e dal castigo della tomba.");
                eveningDhikr2.setText( "Sono soddisfatto di Allah come mio Signore, dell’Islam come mia religione e di Muhammad ﷺ come mio Profeta.");
                welcomeText.setText( "Benvenuto nell'app Azkari. Questa è un'applicazione sperimentale che converte gli adhkar in voce in diverse lingue.");
                break;
            case "de":
//                dhikrText.setText("Oh Allah, mache diese App zu einem Licht auf meinem Weg.");
                morningDhikr1.setText("Sabaha girdik ve mülk Allah’ındır. Hamd Allah’a aittir. Allah’tan başka ilah yoktur, O tektir, ortağı yoktur. Mülk O’nundur, hamd O’nadır ve O her şeye gücü yetendir.\nEy Rabbim! Bu günde ve sonrasında olan hayırları Senden isterim; bu günde ve sonrasında olan kötülüklerden Sana sığınırım.\nTembellikten ve kötü yaşlılıktan Sana sığınırım.\nCehennem azabından ve kabir azabından Sana sığınırım.");
                morningDhikr2.setText( "O Allah, mit Dir beginnen wir den Morgen und mit Dir betreten wir den Abend. Mit Dir leben wir, mit Dir sterben wir, und zu Dir ist die Auferstehung.");
                eveningDhikr1.setText( "Wir sind in den Morgen eingetreten, und das Königreich gehört Allah. Alles Lob gebührt Allah. Es gibt keinen Gott außer Allah, dem Einzigen ohne Partner. Ihm gehört die Herrschaft und das Lob, und Er ist zu allem fähig.\nO mein Herr, ich bitte Dich um das Gute dieses Tages und des Kommenden, und ich suche Zuflucht bei Dir vor dem Übel dieses Tages und des Kommenden.\nO mein Herr, ich suche Zuflucht bei Dir vor Faulheit und schlechter Altersschwäche.\nO mein Herr, ich suche Zuflucht bei Dir vor der Strafe im Feuer und der Strafe im Grab.");
                eveningDhikr2.setText("Ich bin zufrieden mit Allah als meinem Herrn, mit dem Islam als meiner Religion und mit Muhammad ﷺ als meinem Propheten.");
                welcomeText.setText( "Willkommen in der Azkari-App. Dies ist eine Testanwendung, die Bittgebete (Adhkar) in mehreren Sprachen vertont.");
                break;
            case "ru":
//                dhikrText.setText("О Аллах, сделай это приложение светом на моем пути.");
                morningDhikr1.setText( "Мы вступили в утро, и царство принадлежит Аллаху. Хвала Аллаху. Нет божества, кроме Аллаха, Единого, у Которого нет сотоварища. Ему принадлежит власть и хвала, и Он способен на всякую вещь.\nО Аллах, прошу у Тебя блага этого дня и того, что будет после него, и прибегаю к Тебе от зла этого дня и зла того, что будет после него.\nО Аллах, прошу у Тебя защиты от лени и тяжёлой старости.\nО Аллах, прибегаю к Тебе от наказания в Огне и в могиле.");
                morningDhikr2.setText("О, Аллах! С Тобой мы начинаем утро, с Тобой мы вступаем в вечер. С Тобой мы живём, с Тобой умираем, и к Тебе воскресение.");
                eveningDhikr1.setText("Мы вступили в утро, и царство принадлежит Аллаху. Хвала Аллаху. Нет божества, кроме Аллаха, Единого, без сотоварища. Ему принадлежит власть и хвала, и Он всемогущ.\nО мой Господь, я прошу у Тебя блага этого дня и того, что будет после него, и прибегаю к Тебе от зла этого дня и того, что будет после него.\nО мой Господь, я прибегаю к Тебе от лени и бед старости.\nО мой Господь, я прибегаю к Тебе от наказания в аду и наказания в могиле.");
                eveningDhikr2.setText( "Я доволен Аллахом как Господом, Исламом как религией, и Мухаммадом ﷺ как Пророком.");
                welcomeText.setText( "Добро пожаловать в приложение Azkari. Это пробное приложение, которое озвучивает азкар на разных языках.");
                break;
            case "tr":
//                dhikrText.setText("Allah’ım, bu uygulamayı yolumda bir ışık kıl.");
                morningDhikr1.setText("Wir sind in den Morgen eingetreten und das Königreich gehört Allah. Alles Lob gebührt Allah. Es gibt keinen Gott außer Allah, dem Einzigen, ohne Partner. Ihm gehört das Königreich und das Lob, und Er hat Macht über alle Dinge.\nOh Herr, ich bitte Dich um das Gute dieses Tages und das Gute danach, und ich suche Zuflucht bei Dir vor dem Bösen dieses Tages und dem Bösen danach.\nOh Herr, ich suche Zuflucht bei Dir vor Faulheit und schlechter Altersschwäche.\nOh Herr, ich suche Zuflucht bei Dir vor der Strafe im Feuer und der Strafe im Grab.");
                morningDhikr2.setText("Allah’ım! Seninle sabahladık, Seninle akşamladık. Seninle yaşarız, Seninle ölürüz ve Diriltilip Sana döneriz.");
                eveningDhikr1.setText("Sabaha girdik ve mülk Allah’a aittir. Hamd O’na mahsustur. Allah’tan başka ilah yoktur, O tektir, ortağı yoktur. Mülk ve hamd O’na aittir, O her şeye gücü yetendir.\nEy Rabbim! Bu günün ve sonrasının hayrını Senden isterim, bu günün ve sonrasının şerrinden Sana sığınırım.\nEy Rabbim! Tembellikten ve kötü yaşlılıktan Sana sığınırım.\nEy Rabbim! Cehennem azabından ve kabir azabından Sana sığınırım.");
                eveningDhikr2.setText("Allah’tan Rab olarak, İslam’dan din olarak ve Muhammed’den ﷺ peygamber olarak razıyım.");
                welcomeText.setText( "Azkari uygulamasına hoş geldiniz. Bu, zikirleri farklı dillerde sese dönüştüren deneme amaçlı bir uygulamadır.");
                break;
            default:
//                dhikrText.setText("اللهم اجعل هذا التطبيق نورًا في دربي"); // افتراضي عربي
                morningDhikr1.setText(" أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ.\n" +
                        "رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هٰذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هٰذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.");
                morningDhikr2.setText("اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.");
                eveningDhikr1.setText(" أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ.\n" +
                        "رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هٰذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هٰذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ،\n" +
                        "رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ.");
                eveningDhikr2.setText(" رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا.");
                welcomeText.setText("مرحباً بك في تطبيق Azkari، هذا تطبيق تجريبي لتحويل الأذكار إلى صوت بلغات متعددة");

                break;
        }

        // أعد تهيئة TextToSpeech
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(locale);
                tts.setSpeechRate(rate);
                tts.setPitch(pitch);
            }
        });
    }
    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown(); }
        super.onDestroy(); }

}