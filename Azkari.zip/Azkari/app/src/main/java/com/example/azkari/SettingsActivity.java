package com.example.azkari;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;
public class SettingsActivity extends AppCompatActivity {
    private SeekBar rateSeekBar, pitchSeekBar;
    private Spinner languageSpinner;
    private Button saveButton;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        preferences = getSharedPreferences("TalkifyPrefs", MODE_PRIVATE);
        rateSeekBar = findViewById(R.id.rateSeekBar);
        pitchSeekBar = findViewById(R.id.pitchSeekBar);
        languageSpinner = findViewById(R.id.languageSpinner);
        saveButton = findViewById(R.id.saveButton);
        Button installVoiceDataButton = findViewById(R.id.installVoiceDataButton);
        installVoiceDataButton.setOnClickListener(v -> {
            Intent installIntent = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            startActivity(installIntent);
        });
//         إعداد قائمة اللغات
        String[] languages = {"ar", "en", "fr", "it", "de", "ru", "tr"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, languages);
        languageSpinner.setAdapter(adapter);
//          تحميل الإعدادات الحالية
        float savedRate = preferences.getFloat("rate", 1.0f);
        float savedPitch = preferences.getFloat("pitch", 1.0f);
        String savedLang = preferences.getString("lang", "ar");
        rateSeekBar.setProgress((int) (savedRate * 100));
        pitchSeekBar.setProgress((int) (savedPitch * 100));
        languageSpinner.setSelection(adapter.getPosition(savedLang));
        saveButton.setOnClickListener(v -> {
            float rate = rateSeekBar.getProgress() / 100.0f;
            float pitch = pitchSeekBar.getProgress() / 100.0f;
            String lang = languageSpinner.getSelectedItem().toString();
            SharedPreferences.Editor editor = preferences.edit();
            editor.putFloat("rate", rate);
            editor.putFloat("pitch", pitch);
            editor.putString("lang", lang);
            editor.apply();
            finish();
            // العودة للواجهة السابقة }); }
        });
    }
}
