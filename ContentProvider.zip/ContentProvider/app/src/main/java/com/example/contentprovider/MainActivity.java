package com.example.contentprovider;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.database.Cursor;
import android.content.ContentValues;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText nameInput, gradeInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.editText2);
        gradeInput = findViewById(R.id.editText3);
    }

    public void onClickAddName(View view) {
        String name = nameInput.getText().toString().trim();
        String grade = gradeInput.getText().toString().trim();

        if (name.isEmpty() || grade.isEmpty()) {
            Toast.makeText(this, "Please enter both name and grade.", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put(StudentsProvider.NAME, name);
        values.put(StudentsProvider.GRADE, grade);

        Uri uri = getContentResolver().insert(StudentsProvider.CONTENT_URI, values);
        Toast.makeText(this, "Added: " + uri.toString(), Toast.LENGTH_SHORT).show();
    }

    public void onClickRetrieveStudents(View view) {
        Uri uri = StudentsProvider.CONTENT_URI;

        Cursor c = getContentResolver().query(uri, null, null, null, StudentsProvider._ID);
        if (c != null && c.moveToFirst()) {
            do {
                String id = c.getString(c.getColumnIndexOrThrow(StudentsProvider._ID));
                String name = c.getString(c.getColumnIndexOrThrow(StudentsProvider.NAME));
                String grade = c.getString(c.getColumnIndexOrThrow(StudentsProvider.GRADE));

                Toast.makeText(this, id + ", " + name + ", " + grade, Toast.LENGTH_SHORT).show();
            } while (c.moveToNext());

            c.close();
        } else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
    }
}