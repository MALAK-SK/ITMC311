package com.example.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.media.MediaPlayer;
import android.provider.Settings;

import androidx.annotation.Nullable;

public class MyService extends Service {

    private MediaPlayer player;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        // هذه الخدمة لا تدعم الربط
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // تشغيل صوت افتراضي
        player = MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
        player.setLooping(true);
        player.start();

        // إذا قُتل النظام الخدمة، لا تعيد تشغيلها تلقائيًا
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // إيقاف الصوت
        if (player != null) {
            player.stop();
            player.release();
        }
    }
}