package com.example.handler;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ProgressBar myBar;
    private TextView lblTopCaption;
    private EditText txtBox1;
    private Button btnDoSomething;

    private int accum = 0;
    private long startingMills = System.currentTimeMillis();

    private final String PATIENCE = "Some important data is being collected now.\nPlease be patient.";

    // Handler مرتبط بـ Main Thread لتحديث الواجهة
    private final Handler myHandler = new Handler(Looper.getMainLooper());

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ربط الواجهات الرسومية بالكائنات
        lblTopCaption = findViewById(R.id.lblTopCaption);
        myBar = findViewById(R.id.myBar);
        myBar.setMax(100);

        txtBox1 = findViewById(R.id.txtBox1);
        txtBox1.setHint("Foreground distraction. Enter some data here");

        btnDoSomething = findViewById(R.id.btnDoSomething);
        btnDoSomething.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Editable txt = txtBox1.getText();
                Toast.makeText(getBaseContext(), "You said >> " + txt, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        // بدء خيط الخلفية عند بدء النشاط
        Thread myThread1 = new Thread(backgroundTask, "backAlias1");
        myThread1.start();

        myBar.setProgress(0);
    }

    // تحديث الواجهة: هذا الجزء يتم تشغيله في Main Thread بواسطة الـ Handler
    private final Runnable foregroundTask = new Runnable() {
        @Override
        public void run() {
            int progressStep = 5;
            lblTopCaption.setText(PATIENCE + "\nTotal sec. so far: " + (System.currentTimeMillis() - startingMills) / 1000);

            myBar.incrementProgressBy(progressStep);
            accum += progressStep;

            if (accum >= myBar.getMax()) {
                lblTopCaption.setText("Background work is OVER!");
                myBar.setVisibility(View.INVISIBLE);
            }
        }
    };

    // العمل في الخلفية: هذا الجزء يتم تنفيذه في Thread منفصل
    private final Runnable backgroundTask = new Runnable() {
        @Override
        public void run() {
            try {
                for (int n = 0; n < 20; n++) {
                    Thread.sleep(1000); // محاكاة عمل يستغرق 1 ثانية
                    myHandler.post(foregroundTask); // إرسال تحديث إلى الواجهة
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };
}